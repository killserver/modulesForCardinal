<?php

class cardinalEngineDocs extends modules {

	function __construct() {}

	public static $version = "1.0.1";

}