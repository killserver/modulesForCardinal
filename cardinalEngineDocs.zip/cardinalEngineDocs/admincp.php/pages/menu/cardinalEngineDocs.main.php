<?php
$links['cardinalEngineDocs']["cat"][] = array(
'link' => "#",
'title' => "{L_\"Документация по движку \"Cardinal Engine\"\"}",
'type' => "cat",
'access' => true,
'icon' => 'fa-folder-o',
);
$links['cardinalEngineDocs']["item"][] = array(
'link' => "{C_default_http_host}{D_ADMINCP_DIRECTORY}/?pages=Docs",
'title' => "{L_\"Документация по движку \"Cardinal Engine\"\"}",
'type' => "item",
'access' => true,
'icon' => '',
);
?>