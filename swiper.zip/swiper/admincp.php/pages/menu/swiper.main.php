<?php
$links['swiper']["cat"][] = array(
'link' => "{C_default_http_host}".(!defined("ADMINCP_DIRECTORY") ? "admincp.php" : ADMINCP_DIRECTORY)."/?pages=Archer&type=swiper",
'title' => "{L_\"Слайдер Swiper\"}",
'type' => "cat",
'access' => true,
'icon' => 'fa-sliders',
);
$links['swiper']["item"][] = array(
'link' => "{C_default_http_host}".(!defined("ADMINCP_DIRECTORY") ? "admincp.php" : ADMINCP_DIRECTORY)."/?pages=Archer&type=swiper",
'title' => "{L_\"Слайдер Swiper\"}",
'type' => "item",
'access' => true,
'icon' => '',
);
?>