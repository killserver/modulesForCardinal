<?php
/*
Name: Точная настройка визуального редактора текста
Version: 1.0
Author: killserver
OnlyUse: true
 */
if(!defined("IS_CORE")) {
	echo "403 ERROR";
	die();
}

class tinymceAdmin extends modules {

	function __construct() {}

	public static $version = "1.0";

}

?>