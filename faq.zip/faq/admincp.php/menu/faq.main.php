<?php
$links['faq']["cat"][] = array(
'link' => "{C_default_http_host}{D_ADMINCP_DIRECTORY}/?pages=Archer&type=faq",
'title' => "F.A.Q.",
'type' => "cat",
'access' => true,
'icon' => 'fa-spin fa-bug',
);
$links['faq']["item"][] = array(
'link' => "{C_default_http_host}{D_ADMINCP_DIRECTORY}/?pages=Archer&type=faq",
'title' => "F.A.Q.",
'type' => "item",
'access' => true,
'icon' => '',
);
?>