<?php

class ModelFaq extends DBObject {

	public $fId;
	public $fQuestion;
	public $fAnswer;

}