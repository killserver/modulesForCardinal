<?php
if(!defined("IS_CORE")) {
	echo "403 ERROR";
	die();
}

class creatorAdmin extends modules {

	function __construct() {}

	public static $version = "1.0.3";

}

?>