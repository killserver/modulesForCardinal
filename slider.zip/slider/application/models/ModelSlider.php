<?php

class ModelSlider extends DBObject {

	public $slide_id;
	public $slide_title;
	public $slide_img;
	public $slide_descr;

}