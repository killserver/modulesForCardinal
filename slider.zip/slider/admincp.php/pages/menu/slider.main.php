<?php
$links['slider']["cat"][] = array(
'link' => "{C_default_http_host}".(!defined("ADMINCP_DIRECTORY") ? "admincp.php" : ADMINCP_DIRECTORY)."/?pages=Archer&type=slider",
'title' => "{L_\"Слайдер\"}",
'type' => "cat",
'access' => true,
'icon' => 'fa-sliders',
);
$links['slider']["item"][] = array(
'link' => "{C_default_http_host}".(!defined("ADMINCP_DIRECTORY") ? "admincp.php" : ADMINCP_DIRECTORY)."/?pages=Archer&type=slider",
'title' => "{L_\"Слайдер\"}",
'type' => "item",
'access' => true,
'icon' => '',
);
?>