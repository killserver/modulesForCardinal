<?php

class Preloaders extends Core {

	function __construct() {
		if(Arr::get($_GET, "save", false)) {
			callAjax();
			config::Update("preloader", Arr::get($_GET, "save"));
			return false;
		}
		templates::assign_var("maxPreloaders", "8");
		$this->Prints("Preloaders");
	}

}