<?php
$links['Installer']["cat"][] = array(
'link' => "{C_default_http_host}{D_ADMINCP_DIRECTORY}/?pages=Installer",
'title' => "{L_'Установщик модулей'}",
'type' => "cat",
'access' => true,
'icon' => 'fa-list-alt',
);
$links['Installer']["item"][] = array(
'link' => "{C_default_http_host}{D_ADMINCP_DIRECTORY}/?pages=Installer",
'title' => "{L_'Установщик модулей'}",
'type' => "item",
'access' => true,
'icon' => '',
);
?>