<?php

class copyrightForCopy extends modules {
	
	function __construct() {
		$this->regCssJs("{C_default_http_local}js/copyrightForCopy.min.js", "js");
	}

	public static $version = "1.2";
	
}